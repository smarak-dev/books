# Currency Exchange Micro Service - H2

For Istio