insert into TODO
values(10001, 'Learn Spring Boot', false, sysdate(), 'in28minutes');
insert into TODO
values(10002, 'Learn Angular JS', false, sysdate(), 'in28minutes');
insert into TODO
values(10003, 'Learn to Dance', false, sysdate(), 'in28minutes');
