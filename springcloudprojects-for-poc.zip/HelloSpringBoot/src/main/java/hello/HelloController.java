package hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by asamal1 on 7/6/2016.
 */
@RefreshScope
@RestController
public class HelloController {

    @Value("${user.login}")
    private String userName;
    @Value("${user.creds}")
    private String passWord;
    @Value("${spring.application.name}")
    private String appName;
    @Value("${spring.profiles.active}")
    private String activeProfile;
    //
    @Value("${server.port}")
    private String serverPort;
//    @Value("${spring.cloud.config.uri}")
//    private String configUri;

    @Autowired
    private DiscoveryClient discoveryClient;
    @Autowired
    private LoadBalancerClient loadBalancer;


    @RequestMapping("/greetings")
    public String index() {
        return "Hi, what's up! I found user=" + userName + ",creds=" + passWord
                + ",appName=" + appName + ",activeProfile=" + activeProfile
                + ",serverPort=" + serverPort ;
    }

    @RequestMapping("/list")
    public List<String> listInstances() {
        List<String> instances=new ArrayList<String>();

        discoveryClient.getInstances("sample").forEach(
                (instance)->{
                    System.out.println("instance.getHost()="+instance.getHost());
                    System.out.println("instance.getMetadata()="+instance.getMetadata());
                    System.out.println("instance.getPort()="+instance.getPort());
                    System.out.println("instance.isSecure()="+instance.isSecure());
                    System.out.println("instance.getUri()="+instance.getUri());
                    System.out.println("instance.getServiceId()="+instance.getServiceId());
                    System.out.println("instance.getClass()="+instance.getClass());
                    instances.add(instance.getUri().toString());
                }
        );
        return instances;
    }

    @RequestMapping("/list/ribbon")
    public List<String> listRibbonInstances(@RequestParam(value="instance",
            defaultValue="sample") String instanceName) {
        List<String> instances=new ArrayList<String>();

        ServiceInstance instance = loadBalancer.choose(instanceName);

        if(instance!=null)
        {
            System.out.println("instance.getHost()="+instance.getHost());
            System.out.println("instance.getMetadata()="+instance.getMetadata());
            System.out.println("instance.getPort()="+instance.getPort());
            System.out.println("instance.isSecure()="+instance.isSecure());
            System.out.println("instance.getUri()="+instance.getUri());
            System.out.println("instance.getServiceId()="+instance.getServiceId());
            System.out.println("instance.getClass()="+instance.getClass());
            instances.add(instance.getUri().toString());
        }
        return instances;
    }

}