package hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by asamal1 on 6/6/2016.
 */
@SpringBootApplication
@EnableEurekaClient
public class MyApplication {

    public static void main(String[] args) {

        //SpringApplication.run(MyApplication.class, args);

        SpringApplication myApp = new SpringApplication(MyApplication.class);
        myApp.setBanner(
                (env,cls,out)->{
                    out.println("\n AVIJIT SAMAL \n");
                }
        );
        myApp.run(args);

//        System.out.println("Exiting main here...");
//        System.exit(-1);

    }


}