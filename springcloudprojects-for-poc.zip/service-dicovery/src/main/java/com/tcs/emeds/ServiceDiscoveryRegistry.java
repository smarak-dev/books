package com.tcs.emeds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Created by asamal1 on 7/7/2016.
 */
@SpringBootApplication
@EnableEurekaServer
public class ServiceDiscoveryRegistry
{
    public static void main(String[] args)
    {
        SpringApplication.run(ServiceDiscoveryRegistry.class,args);
    }

}//End class
