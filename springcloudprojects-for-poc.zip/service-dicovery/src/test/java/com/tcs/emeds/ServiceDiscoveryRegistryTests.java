package com.tcs.emeds;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by asamal1 on 7/7/2016.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ServiceDiscoveryRegistryTests.class)
public class ServiceDiscoveryRegistryTests
{
    @Test
    public void contextLoads() {
    }
}
